library(swirl)
install.packages("rprojroot")

root_dir <- rprojroot::find_root(rprojroot::has_dir("datatrail-swirl"))

install_course(swc_path = file.path(root_dir, "datatrail-swirl", "DataTrail_Introduction_to_R.swc"))
install_course(swc_path = file.path(root_dir, "datatrail-swirl", "DataTrail_Data_Tidying.swc"))
install_course(swc_path = file.path(root_dir, "datatrail-swirl", "DataTrail_Data_Visualization.swc"))
install_course(swc_path = file.path(root_dir, "datatrail-swirl", "DataTrail_Getting_Data.swc"))
install_course(swc_path = file.path(root_dir, "datatrail-swirl", "DataTrail_Data_Analysis.swc"))
